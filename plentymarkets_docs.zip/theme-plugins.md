
# Theme plugins

Theme plugins allow you to change the appearance of a template plugin without altering its underlying logic. A theme usually overrides stylesheets and may replace or extend Twig templates. This guide provides an overview of creating and activating a basic theme and highlights advanced customisation options.

## Assigning plugin priority

Theme plugins should be loaded after the template plugin but before IO. If **plentyShop LTS** has priority 997 and **IO** has priority 999, assign your theme plugin priority 998 in the plugin set. This ensures that the theme’s styles override the template without being superseded by IO.

## Creating a simple theme

A basic theme that changes the background colour consists of:

```
Theme/
  ├── resources/
  │   ├── css/
  │   │   └── main.css
  │   └── views/
  │       └── content/
  │           └── Theme.twig
  ├── src/
  │   ├── Containers/
  │   │   └── ThemeContainer.php
  │   └── Providers/
  │       └── ThemeServiceProvider.php
  └── plugin.json
```

### plugin.json

```json
{
  "name": "Theme",
  "description": "Basic theme plugin",
  "namespace": "Theme",
  "author": "Your name",
  "keywords": ["theme", "plentyShop LTS", "template"],
  "type": "theme",
  "require": [],
  "serviceProvider": "Theme\Providers\ThemeServiceProvider",
  "dataProviders": [
    {
      "key": "Theme\Containers\ThemeContainer",
      "name": "Dark background",
      "description": "Change the background colour of the plentyShop LTS template"
    }
  ]
}
```

### Service provider and container

The service provider extends `Plenty\Plugin\ServiceProvider` and is typically empty for themes. The container class renders a Twig template defined under `resources/views/content/Theme.twig`:

```php
use Plenty\Plugin\Templates\Twig;

class ThemeContainer
{
    public function call(Twig $twig): string
    {
        return $twig->render('Theme::content.Theme');
    }
}
```

### Twig template and CSS

The Twig template links the theme’s stylesheet:

```twig
<link rel="stylesheet" href="{{ plugin_path('Theme') }}/css/main.css" />
```

In `resources/css/main.css`, override desired styles. For example, set the body background colour:

```css
/* Change background colour */
body {
    background-color: #808080;
}
```

The CSS in a theme has higher priority than the template’s CSS, enabling you to customise colours, fonts and layouts.

## Activating your theme

1. Add the theme plugin to your plugin set and deploy it via the PlentyONE back‑end.  
2. Navigate to **Plugins → Plugin set overview**, open the set and go to **Container links**.  
3. Select your provider (e.g. “Dark background”) and activate the **Template: Style** container.  
4. Save the settings and refresh the front‑end. The new styles take effect without additional configuration.

## Editing template markup

Themes can also override the markup of pages and components by replacing Twig templates or injecting new partials. This allows deeper customisation of the user experience.

* **Page structure** – The page design consists of a `head` (metadata and linked stylesheets) and a `body` divided into wrappers (header, page body, footer). You can overwrite entire templates or only specific wrappers to change the layout.
* **Context classes** – These PHP classes provide data to templates. Contexts such as `GlobalContext`, `CategoryContext`, `ItemListContext` and others supply variables to Twig files. Overriding context classes allows you to adjust the data available in templates.

When modifying template files, your theme lives separately from the template plugin, so updates to the original template do not overwrite your changes.

## Additional customisation

* **Changing the template of a page or component** – Replace specific Twig files under `resources/views` with your own versions.  
* **Changing Vue components** – Override Vue components in `resources/js/src/app/components` to customise functionality and behaviour.  
* **Overwriting Twig macros** – Provide your own macros to change how repeated elements are rendered.  
* **Context variables** – Use context classes to access data such as categories, items, baskets and user settings. A detailed table of variables is available in the official documentation.

Theme plugins provide a flexible way to adapt the look and feel of plentyShop LTS without modifying its core code.

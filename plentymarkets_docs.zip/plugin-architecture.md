
# Plugin architecture

## Plugin structure

To ensure that your PlentyONE plugins function correctly, they need to follow a defined folder and file structure.  
A typical plugin looks like this:

```
PluginDirectory/
    ├── meta/
    ├── resources/
    ├── src/
    ├── tests/
    ├── ui/
    ├── config.json
    ├── contentWidgets.json
    ├── marketplace.json
    ├── plugin.json
    ├── ui.json
    └── README.md
```

* **meta/** – Contains information for the end‑user. This includes icons, preview images and documentation such as a user guide, changelog and support contacts (these must be available in German and English).  
* **resources/** – Holds supplementary files like CSS, JavaScript, images, translation files and Twig templates. These resources are published independently of your PHP code, meaning you can update them faster during development.
* **src/** – The source code of the plugin. PlentyONE plugins use PHP 8.0.
* **tests/** – A suite of tests for your plugin.
* **ui/** – Back‑end views for the PlentyONE interface (AngularJS).
* **config.json** – Defines settings for the plugin so that end‑users can configure options.
* **contentWidgets.json** – Provides information required to make the plugin available as a ShopBuilder widget.
* **marketplace.json** – Contains metadata for publishing the plugin on plentyMarketplace.
* **plugin.json** – A required definition file describing your plugin. It sets the namespace, type (template, theme, etc.), service provider, data providers and other metadata.
* **ui.json** – Specifies entry points for back‑end views.
* **README.md** – Developer documentation.

## Meta files

The **meta** directory stores information relevant to users rather than developers. It usually contains:

* **images/** – Icons used in the PlentyONE back‑end and plentyMarketplace.  
* **documents/** – User documentation, changelogs and support information.  These documents must be provided in German and English; other languages are optional.

## Resource files

Resources are supplemental files (templates, scripts and images) that are made available in the plugin’s public path. When deploying your plugin, resources are published independently of your code:

* **css/** – Compiled CSS files.
* **documents/** – Static assets such as PDFs and fonts.
* **images/** – Images referenced in templates.
* **js/** – JavaScript files; you can organise scripts into subfolders as necessary.
* **lang/** – Translation files for different languages (German and English are required).
* **scss/** – SCSS files. If you use SCSS, you need a script to compile SCSS into CSS.
* **views/** – Twig templates for shop pages. The default plentyShop uses Twig and Vue.js templates.

## Integrating plugins into plentymarkets

A plugin interacts with the PlentyONE system in three major ways:

* **Routes** – Register HTTP routes to call your plugin’s controllers or anonymous functions when a page is accessed. For example, the IO plugin registers all routes for the basic plentyShop.
* **Events** – Listen for pre‑defined events dispatched by the system and execute code when those events occur. For instance, your plugin can listen to an `AfterBuildPlugins` event to re‑generate ShopBuilder content.
* **Cron jobs** – Schedule recurring tasks (e.g. regular imports or background processes) using cron jobs.

Following the prescribed structure and integration points helps avoid unexpected behaviour and ensures your plugin runs smoothly.

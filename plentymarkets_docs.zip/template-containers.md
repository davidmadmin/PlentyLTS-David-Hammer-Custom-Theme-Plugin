
# Template containers in plentyShop LTS

The template plugin for plentyShop LTS defines numerous **containers** that act as placeholders for dynamic content. These containers are linked to data providers defined by your plugins. Understanding the available containers helps you decide where to inject your plugin’s content.

## List of containers

The template defines containers for many parts of the shop:

* **Layout containers** – wrappers for major page sections like the header, footer, page body and sidebars.
* **Page‑specific containers** – containers for static pages (e.g. login, registration), the shopping cart, the checkout process and confirmation pages.
* **Item and category containers** – containers used on single item views, category item lists and search results.
* **My account containers** – containers for account pages (orders, addresses, wish lists, etc.).

Each container has a unique key (e.g. `Ceres::PageDesign.Header`, `Ceres::SingleItem.ItemInfo`) that you reference in your plugin’s `plugin.json` when linking data providers.

## Default layout containers

To simplify integration, you can specify a **default layout container** for your data provider in `plugin.json` using the `defaultLayoutContainer` property.  For example:

```json
"dataProviders": [
  {
    "key": "FacebookPixel\Providers\FacebookPixelCodeProvider",
    "name": "Facebook Pixel",
    "description": "Include the Facebook Pixel code snippet.",
    "defaultLayoutContainer": "Ceres::Script.Loader"
  }
]
```

The fields mean:

* **key** – The fully‑qualified class name of your data provider.
* **name** and **description** – Displayed in the back‑end to describe the data provider.
* **defaultLayoutContainer** – The container that will be automatically linked when the user adds your plugin to their shop. You can only specify one default container per provider.

Adding default layout containers helps merchants integrate your plugin with one click.

For a complete list and visual overview of all containers and the areas they affect, refer to the template containers guide in the official documentation.


# SASS compilation

PlentyONE plugins can be styled using **SASS** or **SCSS**, which compile into CSS. This guide explains the plugin structure for Sass files and two compilation strategies.

## Plugin structure for Sass

The parts of your plugin relevant for Sass compilation look like this:

```
PluginDirectory/
  ├── resources/
  │   ├── css/
  │   └── scss/
  ├── src/
  ├── tools/
  ├── package.json
  └── plugin.json
```

* Write your SASS/SCSS files under `resources/scss/`.
* The plugin build only recognises files in `resources/css/`, so compiled CSS or processed SASS must be placed there.

## Compiling SASS

There are two ways to compile SASS:

### Precompilation

Compile your SASS before building the plugin. This approach suits teams where developers edit and compile the styling themselves. Use a build tool such as **Webpack** with a configuration similar to the one in the plentyShop LTS plugin. Each SCSS file becomes its own entry in `styles.config.js`. The output CSS files are generated under `resources/css/`. Because the compiled files are committed to the repository, deployment is faster.

### Build compilation

Compile SASS during the plugin build. This is useful when you want merchants to override SASS variables via the back‑end. Add a `scss` property to your plugin configuration and let the build process compile SASS into CSS. This makes SASS variables configurable but increases deployment time.

### Build scripts

The `package.json` of the plentyShop LTS plugin provides scripts for building assets:

```
"build": "npm run build:prod && npm run build:dev",
"build:dev": "webpack --progress",
"build:prod": "webpack --env.prod --progress",
"prebuild": "npm run build:sass-vendor",
```

The build script runs both compilation methods; adjust the scripts to your needs or ignore unwanted output. Remember to add generated files to your `.gitignore` or `plenty.ignore` to avoid committing compiled assets.

## Choosing a strategy

* Use **precompilation** if developers maintain the styling and can run build tools locally.  
* Use **build compilation** when you want to expose SASS variables to the back‑end configuration so that merchants can customise colours and other styling options without modifying code.

By organising your SASS files and understanding the build workflow, you can effectively manage styling in your PlentyONE plugins.

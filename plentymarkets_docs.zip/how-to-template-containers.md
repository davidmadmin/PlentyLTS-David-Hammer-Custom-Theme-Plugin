
# How to add a template container

This tutorial walks through creating a small **template container plugin** that displays a placeholder image and text in a plentyShop LTS template.  

## Overview

Template container plugins combine a data provider (a PHP class) with a Twig template and optional configuration. The example plugin consists of a `plugin.json` file, a `config.json` for configurable settings, a service provider, a container class and a Twig template.

### Project structure

```
Placeholder/
  ├── resources/
  │   ├── images/
  │   │   └── placeholder.png
  │   └── views/
  │       └── content/
  │           └── Placeholder.twig
  ├── src/
  │   ├── Containers/
  │   │   └── PlaceholderContainer.php
  │   └── Providers/
  │       └── PlaceholderServiceProvider.php
  ├── config.json
  └── plugin.json
```

### plugin.json

The plugin definition describes your plugin and links the container:

```json
{
  "name": "Placeholder",
  "description": "Template container placeholder plugin",
  "namespace": "Placeholder",
  "author": "Your name",
  "keywords": ["container", "placeholder", "template"],
  "type": "template",
  "require": [],
  "serviceProvider": "Placeholder\Providers\PlaceholderServiceProvider",
  "dataProviders": [
    {
      "key": "Placeholder\Containers\PlaceholderContainer",
      "name": "Placeholder",
      "description": "Display a placeholder image and text"
    }
  ]
}
```

The `dataProviders` array registers the container. Each entry defines the class (`key`), a name and a description shown in the PlentyONE back‑end.

### config.json

Configuration options allow merchants to customise aspects of your container. In the example, only a single text field is defined:

```json
[
  {
    "tab": "Placeholder settings",
    "key": "placeholder.text",
    "label": "Placeholder text",
    "type": "text",
    "default": "This is a placeholder"
  }
]
```

### ServiceProvider

Your service provider extends `Plenty\Plugin\ServiceProvider` and is responsible for registering services. In this simple example, the provider contains no additional logic:

```php
namespace Placeholder\Providers;

use Plenty\Plugin\ServiceProvider;

class PlaceholderServiceProvider extends ServiceProvider
{
    public function register()
    {
        // Register services if necessary
    }
}
```

### Container class

The container class defines a `call()` method that returns the rendered Twig template:

```php
namespace Placeholder\Containers;

use Plenty\Plugin\Templates\Twig;

class PlaceholderContainer
{
    public function call(Twig $twig): string
    {
        return $twig->render('Placeholder::content.Placeholder');
    }
}
```

### Twig template

The Twig template renders the image and text stored in the configuration:

```twig
{% set placeholderText = config("Placeholder.placeholder.text") %}
<img src="{{ plugin_path('Placeholder') }}/images/placeholder.png" />
<h5>{{ placeholderText }}</h5>
```

The `config()` function retrieves the value set in `config.json`. The `plugin_path()` function resolves the path to the plugin’s resources.

### Linking containers

After deploying your plugin, link your container to one or more template containers:

1. Add the plugin to the plugin set in the PlentyONE back‑end and deploy it.
2. Go to **Plugins → Plugin set overview** and open the desired set.
3. In the **Container links** section of the settings plugin, activate your container (e.g. link it to the footer or another container).
4. Save the settings and refresh your storefront; the placeholder content will appear where the container was linked.

This process demonstrates how to build a basic container and connect it to template placeholders.


# Template plugins overview

This guide explains how to set up a development environment for plentyShop LTS template plugins and describes the core and design structures of the template.  

## Setting up your environment

### Installing Node.js

Install **Node.js** (recommended version 14.21.3) and the package manager **npm**. Node.js is required for running build scripts such as Gulp and Webpack.

### Installing PhpStorm

PlentyONE recommends **PhpStorm** as the IDE for developing template plugins. Install PhpStorm and add the **Twig Support** plugin for proper Twig syntax highlighting.  
After installation, clone or download the **plentyShop LTS** and **IO** plugin repositories and open them in PhpStorm.  
Run `npm install` in your terminal to install all dependencies defined in `package.json`.  
Enable **ESLint** in PhpStorm to enforce consistent JavaScript code style.

### Integrating the plugin interface

To enable auto‑completion of PlentyONE interfaces in your IDE, clone the **PlentyONE plugin interface** repository (choose the branch matching your system version, e.g. `stable7`). Then add the plugin interface folder as an external library in PhpStorm (Languages & Frameworks ➜ PHP ➜ Include Path).

### Webpack commands

Webpack builds JavaScript and SCSS for the plentyShop LTS plugin. The package.json defines various scripts:

* `npm start` – runs `webpack --watch` to build assets in development mode and watch for changes.  
* `npm run build` – runs development and production builds and any pre‑ and post‑build steps.  
* `npm run build:dev` / `npm run build:prod` – build JavaScript and SCSS in development or production mode respectively.  
* `npm run build:js` / `npm run build:sass` – compile only JavaScript or Sass.  
* `npm run build:sass-vendor` – bundle vendor SCSS files.  
* `npm run build:widgets` – collect widget settings and build the widgets.

## Core structure of the template

The **src** folder of the IO plugin demonstrates how template plugins are organised.  Key components include:

* **API** – Contains API resources (controllers) for custom REST calls. Each resource extends `ApiResource` and defines its own methods and response codes.  
* **Builder** – Provides helper classes for building arrays of data layer columns. For example, `ItemColumnBuilder` constructs arrays of item fields for repository queries.
* **Constants** – Stores constants such as available languages or category types.
* **Controllers** – Handle requests and render Twig templates; for example, `LoginController` renders the login template.
* **Extensions** – Extend Twig functionality through custom filters, functions or global variables. For instance, `NumberFormatFilter` formats numbers and currencies in templates.
* **Guards** – Contain logic for access control and redirection, e.g. checking whether a user is logged in.
* **Helper** – Helper classes that mediate data between the template and IO plugin (e.g. `TemplateContainer`).
* **Middlewares** – Execute code before and after controller actions; for instance, replacing empty responses with a 404 page.
* **Providers** – Service providers are the entry point of your plugin; route service providers register routes that map URLs to controllers or closures.
* **Services** – Provide methods for business logic. Controllers and API resources call services such as `BasketService` to load data.

## Design structure

The **resources** folder of the plentyShop LTS plugin contains design assets:

* **CSS** – Compiled CSS files.  
* **Documents** – Static files such as fonts and PDFs.  
* **Images** – Company logos and other images used in templates.  
* **JS** – JavaScript files; the `dist` folder contains compiled files (e.g. `plugin-ceres-app.js`) and the `src` folder contains Vue components and other sources.  
* **Lang** – Translation files in `.properties` format for different languages.  Keys have prefixes such as `basket`, `acc`, `itemCategory`, etc., to organise translations by template area.  A second `lang` folder under `resources/js/lang` contains translation files compiled with the `build:lang` gulp task.  
* **SCSS** – SCSS files imported by a main file like `Ceres.scss`. A grunt or Webpack task compiles these into CSS.  
* **Views** – Twig templates. The `PageDesign.twig` file is the base layout of your shop. Static pages (login, registration) reside in sub‑folders. Vue.js template files are organised within `resources/views/templates` to match the Vue components in `resources/js/src/app/components`.

Understanding both the core structure (PHP code) and the design structure (assets and templates) is essential when developing template plugins.
